# 1.1.1
- Update mirror list.

# 1.1.0
- Update mirror list.

# 1.0.0
- Update mirror list.

# 0.8.2+1
- Update mirror list.

# 0.8.2
- Update mirror list.

# 0.8.1
- Fix file extension mapping.

# 0.8.0
- Switched to new paging layout.

# 0.7.3+2
- Added mirror selection.

# 0.7.3+1
- Update libgen domains.

# 0.7.3
- Handle pagination count.

# 0.7.2
- Handle total result count.

# 0.7.1
- Handle total result count.

# 0.7.0
- Handle updated result count.

# 0.6.0
- Handle updated welib-like layout.

# 0.5.1
- Updated max limit.

# 0.5.0
- Updated dependencies.

# 0.4.4
- Added getJournalDownloadLink by DOI.

# 0.4.3
- Added getJournalDownloadLink by Md5.

# 0.4.2
- Added getJournalDownloadLink.

# 0.4.1
- Added getInfo.

# 0.4.0
- Removed libgenRS support.

# 0.3.9
- Added libGenli mirrors & timeOut for libgenRS.

# 0.3.8
- Fixed libgenRS download source to use books.ms.

# 0.3.7
- Fixed libgenRS download source to use IPFS.

# 0.3.6
- Fixed libgenRS download source.

# 0.3.5
- Added sources info in search results.

# 0.3.4
- Removed goodreads to own package.

# 0.3.3
- Updated book_scraper dart package.

# 0.3.2
- Uses book_scraper dart package.

# 0.3.1
- Uses book_scraper dart package.

# 0.3.0
- Uses book_scraper package.

# 0.2.3
- fixes 10000+ result parsing.

# 0.2.2
- Added support for journal source filters.

# 0.2.1
- Exposed new api's

# 0.2.0+1
- Updated examples

# 0.2.0
- Added support for Journals.
- Added support for source filters.
- Fallback cover color (Hls).
- Complete language list.

# 0.1.1
- Removed duplicate results.

# 0.1.0
- Updated parser.

# 0.0.9
- Support for Year of publication.

# 0.0.8
- Support for member download.

# 0.0.7
- Improve query speed.

# 0.0.6+1
- Extended Categories for data & domain.

# 0.0.6
- Added support for more book types & more downnload links.

# 0.0.5+3
- Improved result filtering.

# 0.0.5+2
- Fixed skip offset.

# 0.0.5+1
- Updated plugin documentation with skip support.

# 0.0.5
- Support result limits with skip.

# 0.0.4+1
- Improve book genre result.

# 0.0.4
- Remove Flutter sdk dependency.

# 0.0.3
- Downgrade Min Dart sdk version.

# 0.0.2+4
- Expose GoodReads collection Request.

# 0.0.2+3
- Added GoodReads collection support.

# 0.0.2+2
- Expose enums.

# 0.0.2+1
- Update bsd license & improve lib documentation.

# 0.0.1
- Initial release.