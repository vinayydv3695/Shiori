import 'package:annas_archive_api/annas_archive_api.dart';

Future<void> main() async {
  // Finds books from Anna's Archive.
  await AnnaApi()
      .find(
        const SearchRequest(
          query: 'harry potter',
          author: 'rowling',
          categories: [Category.fiction],
          sources: [AnnaSource.zLibrary, AnnaSource.internetArchive],
          formats: [Format.epub, Format.pdf],

          language: Language.french,
          sort: SortOption.smallest,
        ),
      )
      .then((response) async {
        for (final Book book in response.books) {
          print(book.title);
        }

        // Get download links for a book.
        await AnnaApi().getDownloadLinks(response.books.first.md5).then((
          downloadLinks,
        ) {
          for (final String link in downloadLinks) {
            print(link);
          }
        });
      });

  // Finds journals from Anna's Archive.
  await AnnaApi()
      .findJournal(
        const SearchJournalRequest(
          query: '',
          language: Language.french,
          sources: [AnnaSource.libgenLi],
          sort: SortOption.newest,
        ),
      )
      .then((response) {
        for (final Book book in response.books) {
          print(book.title);
        }
      });
}
