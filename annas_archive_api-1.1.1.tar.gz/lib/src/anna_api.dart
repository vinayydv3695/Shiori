import 'dart:convert';

import 'package:annas_archive_api/annas_archive_api.dart';
import 'package:annas_archive_api/src/models/member_download_result.dart';
import 'package:beautiful_soup_dart/beautiful_soup.dart';
import 'package:book_scraper/book_scraper.dart';
import 'package:collection/collection.dart';
import 'package:compute/compute.dart';
import 'package:http/http.dart' as http;

/// This class contains methods for interacting with Anna's Archive.
class AnnaApi extends BaseBookApi {
  final MirrorSelector _mirrorSelector = MirrorSelector({
    'https://annas-archive.gl': 5,
    'https://annas-archive.pk': 5,
    'https://annas-archive.gd': 5,
  });

  static const _maximumDownloadLinkDuration = Duration(seconds: 3);
  @override
  String get baseUrl => _mirrorSelector.nextMirror;

  /// Returns a List of books based on a search request.
  Future<SearchResponse<Book>> find(SearchRequest searchRequest) async {
    final baseUrl = _mirrorSelector.nextMirror;
    final stopwatch = Stopwatch()..start();
    try {
      final searchTermQuery =
          '&q=${Uri.encodeComponent(searchRequest.query.trim())}';

      final author = searchRequest.author.replaceAll(',', '');
      final authorQuery = '&termtype_1=author&termval_1=$author';

      final filtersQuery = _buildFiltersQuery(searchRequest);

      final url =
          '$baseUrl/search?index=&page=1$searchTermQuery$authorQuery$filtersQuery';

      final soup = await cookSoup(url);
      final resultCount = getTotalResultCount(soup);
      if (resultCount == null || resultCount == 0) {
        await _mirrorSelector.reportResult(
          url: baseUrl,
          success: true,
          latencyMs: stopwatch.elapsedMilliseconds,
        );
        return SearchResponse<Book>(total: 0);
      }

      final books = await _getBooks(
        baseUrl: baseUrl,
        searchTermQuery: searchTermQuery,
        authorQuery: authorQuery,
        filtersQuery: filtersQuery,
        page: searchRequest.page,
      );

      final conversionBookRequest = ConversionRequest<Book, Bs4Element>(
        books,
        _getBookfromAnna,
      );

      return compute(
        convertListToModelWithErrorCount<Book, Bs4Element>,
        conversionBookRequest,
      ).then((result) async {
        await _mirrorSelector.reportResult(
          url: baseUrl,
          success: true,
          latencyMs: stopwatch.elapsedMilliseconds,
        );
        return SearchResponse<Book>(total: resultCount, books: result.results);
      });
    } catch (e) {
      print('${searchRequest.hashCode} - Error finding books: $e');
      await _mirrorSelector.reportResult(
        url: baseUrl,
        success: false,
        latencyMs: stopwatch.elapsedMilliseconds,
      );
      throw Exception('Error finding books');
    }
  }

  /// Returns a List of books based on a search request.
  Future<SearchResponse<Book>> findJournal(
    SearchJournalRequest searchJournalRequest,
  ) async {
    final baseUrl = _mirrorSelector.nextMirror;
    final stopwatch = Stopwatch()..start();
    try {
      final searchTermQuery =
          '&q=${Uri.encodeComponent(searchJournalRequest.query.trim())}';

      final author = searchJournalRequest.author.replaceAll(',', '');
      final authorQuery = '&termtype_1=author&termval_1=$author';

      final filtersQuery = _buildJournalFiltersQuery(searchJournalRequest);

      final url =
          '$baseUrl/search?index=journals&page=1$searchTermQuery$authorQuery$filtersQuery';
      final soup = await cookSoup(url);
      final resultCount = getTotalResultCount(soup);
      if (resultCount == null || resultCount == 0) {
        await _mirrorSelector.reportResult(
          url: baseUrl,
          success: true,
          latencyMs: stopwatch.elapsedMilliseconds,
        );
        return SearchResponse<Book>(total: 0);
      }

      final books = await _getBooks(
        isJournal: true,
        baseUrl: baseUrl,
        searchTermQuery: searchTermQuery,
        authorQuery: authorQuery,
        filtersQuery: filtersQuery,
        page: searchJournalRequest.page,
      );

      final conversionBookRequest = ConversionRequest<Book, Bs4Element>(
        books,
        _getBookfromAnna,
      );

      return compute(
        convertListToModelWithErrorCount<Book, Bs4Element>,
        conversionBookRequest,
      ).then((result) async {
        await _mirrorSelector.reportResult(
          url: baseUrl,
          success: true,
          latencyMs: stopwatch.elapsedMilliseconds,
        );
        return SearchResponse<Book>(total: resultCount, books: result.results);
      });
    } catch (e) {
      print('${searchJournalRequest.hashCode} - Error finding books: $e');
      await _mirrorSelector.reportResult(
        url: baseUrl,
        success: false,
        latencyMs: stopwatch.elapsedMilliseconds,
      );
      throw Exception('Error finding books');
    }
  }

  /// Returns a Map of descriptions and codes for a given md5.
  Future<Map<String, Map<String, List<String>>>> getInfo(String md5) async {
    Map<String, List<String>> getDescriptions(BeautifulSoup soup) {
      final List<MapEntry<String, String>> descriptions = [];

      final descriptionContainer = soup.find(
        'div',
        attrs: {'class': 'mt-4 line-clamp-[10] js-md5-top-box-description'},
      );

      final titles = descriptionContainer
          ?.findAll('div', attrs: {'class': 'text-xs text-gray-500 uppercase'})
          .map((e) => e.text);

      final contents = descriptionContainer
          ?.findAll('div', attrs: {'class': 'mb-1'})
          .map((e) => e.text);

      titles?.forEach((title) {
        descriptions.add(
          MapEntry(title, contents!.elementAt(titles.toList().indexOf(title))),
        );
      });
      final descriptionsTransformed = <String, List<String>>{};
      groupBy(descriptions, (obj) => obj.key).forEach((key, value) {
        descriptionsTransformed[key] = value.map((e) => e.value).toList();
      });
      return descriptionsTransformed;
    }

    Map<String, List<String>> getCodes(BeautifulSoup soup) {
      final List<MapEntry<String, String>> codes = [];
      final codesContainer = soup.find(
        'div',
        attrs: {'class': 'js-md5-codes-container'},
      );
      codesContainer
          ?.findAll(
            'a',
            attrs: {
              'class':
                  'rounded-sm flex mb-1 mr-1 pr-1 border border-[#aaa] opacity-60 hover:opacity-80 aria-selected:opacity-100 custom-a js-md5-codes-tabs-tab max-w-[calc(50%-8px)]',
            },
          )
          .forEach((codeContainer) {
            final codeContents = codeContainer
                .findAll('span')
                .map((e) => e.text)
                .toList();

            codes.add(MapEntry(codeContents[0], codeContents[1]));
          });

      final codesTransformed = <String, List<String>>{};
      groupBy(codes, (obj) => obj.key).forEach((key, value) {
        codesTransformed[key] = value.map((e) => e.value).toList();
      });
      return codesTransformed;
    }

    final baseUrl = _mirrorSelector.nextMirror;
    final stopwatch = Stopwatch()..start();
    try {
      final soup = await cookSoup('$baseUrl/md5/$md5');
      final descriptions = getDescriptions(soup);
      final codes = getCodes(soup);
      await _mirrorSelector.reportResult(
        url: baseUrl,
        success: true,
        latencyMs: stopwatch.elapsedMilliseconds,
      );
      return {'descriptions': descriptions, 'codes': codes};
    } catch (e) {
      await _mirrorSelector.reportResult(
        url: baseUrl,
        success: false,
        latencyMs: stopwatch.elapsedMilliseconds,
      );
      throw Exception('Error getting info');
    }
  }

  /// Returns a list of download links for a book for a given md5.
  Future<List<String>> getDownloadLinks(String md5) async {
    final results = <String?>[];

    // Wait for all futures to complete or timeout individually
    await Future.wait(
      [
        _getLibGenLi(baseUrl: 'https://libgen.li', md5: md5),
        _getLibGenLi(baseUrl: 'https://libgen.vg', md5: md5),
        // _getLibGenLi(baseUrl: 'https://libgen.gs', md5: md5),
      ].map((future) {
        return future
            .timeout(_maximumDownloadLinkDuration, onTimeout: () => null)
            .then(results.add);
      }),
    );

    return results.whereType<String>().toList();
  }

  Future<String?> _getLibGenLi({
    required String baseUrl,
    required String md5,
  }) async {
    return cookSoup('$baseUrl/ads.php?md5=$md5')
        .then((soup) {
          final link = soup
              .find(
                'td',
                attrs: {
                  'align': 'center',
                  'valign': 'top',
                  'bgcolor': '#A9F5BC',
                },
              )
              ?.find('a')
              ?.attributes['href'];

          return link != null ? '$baseUrl/$link' : null;
        })
        .catchError((onError) => null);
  }

  // Future<String?> _getLibGenRsDownloadLink(String url) {
  //   return cookSoup(url).then((soup) {
  //     return soup.find('a')?.attributes['href'];
  //   }).catchError(
  //     (onError) {
  //       return null;
  //     },
  //   );
  // }

  Future<MemberDownloadResponse?> getMemberDownloadLinks({
    required String md5,
    required String membershipKey,
  }) async {
    final baseUrl = _mirrorSelector.nextMirror;
    final stopwatch = Stopwatch()..start();
    final url =
        '$baseUrl/dyn/api/fast_download.json?md5=$md5&key=$membershipKey';

    try {
      final response = await _fetchMemberDownloadWithInfo(url);
      await _mirrorSelector.reportResult(
        url: baseUrl,
        success: true,
        latencyMs: stopwatch.elapsedMilliseconds,
      );
      return MemberDownloadResponse(
        accountInfo: response.accountInfo,
        fast: response.downloadUrl,
        basic: await getDownloadLinks(md5),
      );
    } catch (e) {
      await _mirrorSelector.reportResult(
        url: baseUrl,
        success: false,
        latencyMs: stopwatch.elapsedMilliseconds,
      );
      return null;
    }
  }

  /// Returns the number of results from Anna's Archive.
  @override
  int? getTotalResultCount(BeautifulSoup soup) {
    try {
      final String count =
          soup
              .findAll(
                'a',
                class_:
                    'custom-a relative inline-flex items-center px-4 py-2 font-semibold text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0',
              )
              .lastOrNull
              ?.text ??
          soup
              .findAll(
                'a',
                class_:
                    'custom-a relative z-10 inline-flex items-center bg-[#0195ff] px-4 py-2 font-semibold text-white focus:z-20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0195ff]',
              )
              .lastOrNull
              ?.text ??
          '0';

      return int.tryParse(count)!;
    } catch (e) {
      return null;
    }
  }

  /// Returns the URL ending for a search request.
  String _buildFiltersQuery(SearchRequest searchRequest) {
    var urlEnding = '&acc=external_download';

    //Sources
    final supportedSources = AnnaSource.values.where(
      (s) => s != AnnaSource.invalid,
    );
    for (final source in supportedSources) {
      if (searchRequest.sources.contains(source)) {
        urlEnding += '&src=${source.apiName}';
      }
    }

    // Content
    for (final category in Category.values) {
      if (searchRequest.categories.contains(category)) {
        urlEnding += '&content=${category.apiName}';
      }
    }

    // Formats
    for (final format in Format.values) {
      if (searchRequest.formats.contains(format)) {
        urlEnding += '&ext=${format.name}';
      }
    }

    return urlEnding +=
        '&lang=${searchRequest.language.code}&sort=${searchRequest.sort.value}';
  }

  /// Returns the URL ending for a search request.
  String _buildJournalFiltersQuery(SearchJournalRequest searchRequest) {
    var urlEnding = '&acc=external_download';

    //Sources
    final supportedSources = [
      AnnaSource.sciHub,
      AnnaSource.libgenLi,
      AnnaSource.nexusStc,
      AnnaSource.uploads,
      AnnaSource.zLibrary,
      AnnaSource.magzDb,
    ];
    for (final source in supportedSources) {
      if (searchRequest.sources.contains(source)) {
        urlEnding += '&src=${source.apiName}';
      }
    }

    return urlEnding +=
        '&lang=${searchRequest.language.code}&sort=${searchRequest.sort.value}';
  }

  Book _getBookfromAnna(Bs4Element soupElement) {
    bool hasIssue(BeautifulSoup soup) {
      return soup.findAll('div', class_: 'text-xs lg:text-sm').isNotEmpty;
    }

    String? getYear(BeautifulSoup soup) {
      return soup
          .find(
            'div',
            class_: 'truncate leading-[1.2] lg:leading-[1.35] max-lg:text-xs',
          )
          ?.string
          .split(',')
          .last
          .trim();
    }

    String getAuthor(BeautifulSoup soup) {
      return soup
          .find(
            'a',
            class_:
                'line-clamp-[2] overflow-hidden break-words block custom-a text-sm hover:opacity-70 leading-[1.2] mt-1',
          )!
          .text
          .trim();
    }

    String getTitle(BeautifulSoup soup) {
      return soup
              .find(
                'a',
                class_:
                    'line-clamp-[3] overflow-hidden break-words js-vim-focus custom-a text-[#2563eb] inline-block outline-offset-[-2px] outline-2 rounded-[3px] focus:outline font-semibold text-lg leading-[1.2] hover:opacity-80 mt-1',
              )
              ?.text ??
          soup
              .find(
                'a',
                class_:
                    'line-clamp-[3] overflow-hidden break-words js-vim-focus custom-a text-[#2563eb] inline-block outline-offset-[-2px] outline-2 rounded-[3px] focus:outline font-semibold text-lg leading-[1.2] hover:opacity-80',
              )
              ?.text ??
          '';
    }

    String getCoverUrl(BeautifulSoup soup) {
      return soup.img?.attributes['src'] ?? '';
    }

    String? getCoverColor(BeautifulSoup soup) {
      return soup
          .find(
            'div',
            class_:
                'absolute top-0 left-0 w-full h-full p-2 flex flex-col text-[7pt] leading-[1.1] break-words overflow-hidden select-none hidden js-aarecord-list-fallback-cover',
          )
          ?.attributes['style']
          ?.split('background-color: ')
          .last;
    }

    String getMd5(BeautifulSoup soup) {
      return soup.a!.attributes['href']!.split('/')[2];
    }

    List<String> getSplitMetadata(BeautifulSoup soup) {
      return soup
          .find(
            'div',
            class_:
                'text-gray-800 dark:text-slate-400 font-semibold text-sm leading-[1.2] mt-2',
          )!
          .string
          .split('·');
    }

    String getSize(List<String> splitMetadata) {
      for (int i = 0; i < splitMetadata.length - 1; i++) {
        final entry = splitMetadata[i];

        if (entry.trim().toLowerCase().endsWith('mb')) {
          return entry.trim();
        }
      }

      return 'Unknown';
    }

    String getGenre(List<String> splitMetadata) {
      if (splitMetadata.isEmpty) return 'Unknown';

      for (int i = 0; i < splitMetadata.length - 1; i++) {
        final entry = splitMetadata[i].toLowerCase();

        if (entry.contains('magazine')) {
          return 'Magazine';
        }

        if (entry.contains('comic')) {
          return 'Comic';
        }

        if (entry.toLowerCase().contains('non-fiction')) {
          return 'Non-Fiction';
        }

        if (entry.contains('fiction')) {
          return 'Fiction';
        }

        if (entry.contains('unknown')) {
          return 'Unknown';
        }
      }

      return 'Unknown';
    }

    String getUncommentedHtml(Bs4Element soupElement) {
      return soupElement.outerHtml.replaceAll('<!--', '').replaceAll('-->', '');
    }

    String? extractFormatRegex(List<String> list) {
      final pattern =
          r'\b('
          '${Format.pdf.extension}|'
          '${Format.epub.extension}|'
          '${Format.mobi.extension}|'
          '${Format.azw3.extension}'
          r')\b';

      final regex = RegExp(pattern, caseSensitive: false);

      for (final item in list) {
        final cleaned = item.trim().replaceAll('.', '');
        final match = regex.firstMatch(cleaned);
        if (match != null) {
          return match.group(0)!.toLowerCase(); // standardize output
        }
      }
      return null;
    }

    Format getFormat(List<String> splitMetadata) {
      final r = extractFormatRegex(splitMetadata);
      return Format.fromString(r ?? '');
    }

    List<String> getSources(List<String> splitMetadata) {
      final sources = splitMetadata
          .firstWhere(
            (val) => val.contains('🚀') || val.contains('🧬'),
            orElse: () => '',
          )
          .trim();

      final x = sources
          .split('🧬/')
          .last
          .split('🚀/')
          .last
          .split('/')
          .map((e) => e.trim())
          .toList();

      return x;
    }

    final soup = BeautifulSoup(getUncommentedHtml(soupElement));

    if (hasIssue(soup)) {
      throw Exception('Issue with book');
    }

    final splitMetadata = getSplitMetadata(soup);

    return Book(
      title: getTitle(soup),
      imgUrl: getCoverUrl(soup),
      imgFallbackColor: getCoverColor(soup),
      md5: getMd5(soup),
      size: getSize(splitMetadata),
      genre: getGenre(splitMetadata),
      format: getFormat(splitMetadata),
      sources: getSources(splitMetadata),
      author: getAuthor(soup),
      year: getYear(soup),
    );
  }

  Future<List<Bs4Element>> _getBooks({
    // required Map<int, int> batches,
    required int page,
    required String baseUrl,
    required String searchTermQuery,
    required String authorQuery,
    required String filtersQuery,
    bool isJournal = false,
  }) async {
    final books = <Bs4Element>[];

    // Construct the URL for the batch
    final batchUrl =
        '$baseUrl/search?index=${isJournal ? 'journals' : ''}&page=$page$searchTermQuery$authorQuery$filtersQuery';
    // final encodedUrl = Uri.encodeFull(batchUrl);

    // Fetch, cook the soup then strip partial results
    final batchSoup = _removePartialResults(await cookSoup(batchUrl));

    books.addAll(
      batchSoup.findAll(
        'div',
        class_: 'flex  pt-3 pb-3 border-b last:border-b-0 border-gray-100',
      ),
    );

    return books;
  }

  BeautifulSoup _removePartialResults(BeautifulSoup batchSoup) {
    //     const test = r'''
    // Bs4Element (<div class="flex  pt-3 pb-3 border-b last:border-b-0 border-gray-100">
    //         <a href="/md5/c282a85faa0499308c2c77d02c591051" class="custom-a block mr-2 sm:mr-4 hover:opacity-80">
    //           <div id="list_cover_aarecord_id__md5:c282a85faa0499308c2c77d02c591051" class="w-20 h-[7.5rem] sm:w-24 sm:h-36 rounded shadow relative overflow-hidden text-left">
    //     <img class="w-full h-full object-cover transition-transform relative z-10 rounded" src="https://s3proxy.cdn-zlib.sk//covers299/collections/userbooks/88d7a5d44145d50a58a8b57c818591a5431e941cdbc6d311cda3964f5dbcb5ff.jpg" alt="" referrerpolicy="no-referrer" loading="lazy" decoding="async" onerror="this.parentNode.querySelector('.js-aarecord-list-fallback-cover').classList.remove('hidden'); this.parentNode.removeChild(this)">
    //     <div class="absolute top-0 left-0 w-full h-full p-2 flex flex-col text-[7pt] leading-[1.1] break-words overflow-hidden select-none hidden js-aarecord-list-fallback-cover" style="background-color: hsl(0, 100%, 90%)">
    //       <div class="font-bold text-violet-900 line-clamp-[5]" data-content="Leave Me Behind"></div>
    //       <div class="font-bold text-amber-900 line-clamp-[2] mt-2" data-content="K. M. Moronova"></div>
    //     </div>
    //   </div>
    //         </a>
    //         <div class="max-w-full overflow-hidden flex flex-col justify-around">
    //           <div>
    // <a href="/md5/c282a85faa0499308c2c77d02c591051" class="line-clamp-[3] overflow-hidden break-words js-vim-focus custom-a text-[#2563eb] inline-block outline-offset-[-2px] outline-2 rounded-[3px] focus:outline font-semibold text-lg leading-[1.2] hover:opacity-80 ">Leave Me Behind</a><a href="/search?q=K. M. Moronova" class="line-clamp-[2] overflow-hidden break-words block custom-a text-sm hover:opacity-70 leading-[1.2] mt-1"><span class="icon-[mdi--user-edit] text-base align-sub"></span> K. M. Moronova</a><a href="/search?q=Independent Publishers Group" class="line-clamp-[2] overflow-hidden break-words block custom-a text-sm hover:opacity-70 leading-[1.2] mt-1"><span class="icon-[mdi--company] text-base align-sub"></span> Independent Publishers Group, 2024</a>          </div>
    //           <div>
    //             <div class="line-clamp-[5]"></div><!-- Only to make sure Tailwind generates it -->
    // <div class="relative"><div class="line-clamp-[2] overflow-hidden break-words text-sm text-gray-600 mt-2 mb-2 leading-[1.3]">Nell Gallows is the sole survivor of an elite dark forces squad, Riøt, after a detrimental attack two years ago. Unsurprisingly, she’s being put up as the top candidate for the special ops Malum. The squad that goes where no one else will or can. There’s only one Malum blames their one casualty from the Patagonia mission on the Riøt squad. So what is she to do when she finds herself on a plane to California and on her way to a sure death sentence? A one-night stand. At least, that’s all it was supposed to be—one last night to be free. Only, she finds out too late that the dark and mysterious man she solely wanted as a fling is not only her new comrade but also the one she dreaded meeting most—her immediate superior and untouchable devil in the field. Bones. He’s hell on earth—cruel and unforgiving, but most of all, he hates her, and he makes sure she knows it. And yet, she finds herself unwilling to leave his side when he’s unable to get to the evac point when their mission goes awry. She stays behind with the devil and the secrets he keeps. They only have one another to trust when no faith is left.</div> <a href="#" class="hidden js-aarecord-list-read-more absolute bottom-[-1px] right-0 text-xs bg-white pl-[6px] pr-1 py-[2px]" onclick="this.parentElement.children[0].classList.remove('line-clamp-[2]'); this.parentElement.children[0].classList.add('line-clamp-[5]'); this.parentNode.removeChild(this); event.preventDefault(); return false;">Read more…</a> <script>window.addReadMoreButton(document.currentScript.parentElement);</script></div>          </div>
    //           <div class="text-gray-800 dark:text-slate-400 font-semibold text-sm leading-[1.2] mt-2">English [en] · EPUB · 0.5MB · 2024 · 📕&nbsp;Book (fiction) · 🚀/zlib    · <a href="#" class="custom-a text-[#2563eb] inline-block outline-offset-[-2px] outline-2 rounded-[3px] focus:outline font-semibold text-sm leading-none hover:opacity-80 relative"><span class="text-[15px] align-text-bottom inline-block icon-[pepicons-pencil--bookmark-filled] mr-[1px]"></span><!--TODO:TRANSLATE-->Save<script>
    //       (function() {
    //         var scriptParent = document.currentScript.parentElement;
    //         scriptParent.addEventListener("click", (event) => {
    //           var aarecord_id = "md5:c282a85faa0499308c2c77d02c591051";
    //           var leftPos = 0;
    //           var innerStyles = 'width: calc(100% - 16px); margin-left: 8px'
    //           if (document.body.clientWidth > 800) {
    //             leftPos = (scriptParent.getBoundingClientRect().left + window.scrollX);
    //             innerStyles = 'transform: translateX(-100%); max-width: ' + (scriptParent.getBoundingClientRect().left + window.scrollX) + 'px';
    //           }

    //           var reloadNode = document.createElement('div');
    //           document.body.appendChild(reloadNode);
    //           reloadNode.innerHTML = '<div class="absolute left-0 top-0 right-0 bottom-0" style="background:rgba(0,0,0,0.2); z-index: 9999999"><div role="dialog" class="js-lists-popover-inner absolute p-4 cursor-auto bg-white shadow-xl rounded-lg" style="left: ' + leftPos + 'px; top: ' + (scriptParent.getBoundingClientRect().top + window.scrollY) + 'px; ' + innerStyles + '"><span class="leading-none align-[-3px] text-[#555] inline-block icon-[svg-spinners--ring-resize]"></span></span></div></div>'

    //           fetch("/dyn/lists/" + aarecord_id + '?is_popover=true').then((response) => response.ok ? response.text() : 'Error 921857').then((text) => {
    //             reloadNode.querySelector('.js-lists-popover-inner').innerHTML = text;
    //             window.executeScriptElements(reloadNode);

    //             function closePopover() {
    //               document.body.removeChild(reloadNode);
    //               document.removeEventListener("keydown", escapeHandler, true);
    //             }

    //             var escapeHandler = function(e) {
    //               if (e.key === "Escape") {
    //                 closePopover();
    //               }
    //             };
    //             document.addEventListener("keydown", escapeHandler, true);

    //             reloadNode.querySelector('.js-list-popover-close').addEventListener('click', function(event) {
    //               closePopover();
    //               event.preventDefault();
    //               return false;
    //             });

    //             reloadNode.querySelector('.js-list-popover-close').focus();
    //           });
    //           event.preventDefault();
    //           document.activeElement.blur();
    //           return false;
    //         });
    //       })();
    //     </script></a>
    //     <span class="text-xs text-gray-500"><script>
    //       (function() {
    //         var scriptParent = document.currentScript.parentElement;

    //         const md5 = "c282a85faa0499308c2c77d02c591051";

    //         // # "text/css" for DDOS-GUARD caching.
    //         fetch("/dyn/md5/inline_info/" + md5, { headers: { 'Accept': 'text/css' } }).then((response) => response.json()).then((json) => {
    //           const icons = [
    //             // TODO:TRANSLATE
    //             ` · <span title="Downloads" class="whitespace-nowrap"><span class='text-[14px] align-text-bottom inline-block icon-[typcn--download] mr-[3px]'></span>${json.downloads_total.toLocaleString()}</span> <span title="Downloads">`,
    //             // TODO:TRANSLATE
    //             json.great_quality_count && `<span title="Great quality" class="whitespace-nowrap text-yellow-500"><span class='text-[14px] align-text-bottom inline-block icon-[material-symbols--star] mr-[2px]'></span>${json.great_quality_count.toLocaleString()}</span></span>`,
    //             // TODO:TRANSLATE
    //             json.lists_count && `<span title="Lists" class="whitespace-nowrap"><span class='text-[14px] align-[-3px] inline-block icon-[pepicons-pencil--bookmark-filled] mr-[2px]'></span>${json.lists_count.toLocaleString()}</span></span>`,
    //             // TODO:TRANSLATE
    //             json.comments_count && `<span title="Comments" class="whitespace-nowrap"><span class='text-[14px] align-[-3px] icon-[mdi--comment] mr-[4px]'></span>${json.comments_count.toLocaleString()}</span></span>`,
    //             // TODO:TRANSLATE
    //             json.reports_count && `<span title="File issues" class="whitespace-nowrap text-red-500"><span class='text-[14px] align-text-bottom inline-block icon-[material-symbols--warning] mr-[2px]'></span>${json.reports_count.toLocaleString()}</span></span>`,
    //           ]
    //           scriptParent.innerHTML = '<span class="align-text-bottom">' + icons.filter(Boolean).join(` · `) + '</span>';
    //         });
    //       })();
    //     </script></span>
    // </div>
    //           <div class="hidden">base score: 11055.0, final score: 167534.27</div>
    //         </div>
    //       </div>)
    // ''';

    final resultContainer = batchSoup
        .find(
          'div',
          class_: 'bg-white px-2 rounded-tr-lg rounded-b-lg shadow-lg',
        )
        .toString();

    return BeautifulSoup.fragment(resultContainer);
  }

  Future<MemberDownloadResult> _fetchMemberDownloadWithInfo(String url) async {
    return http
        .get(Uri.parse(url))
        .then((response) {
          if (response.statusCode == 200) {
            final decoded = jsonDecode(response.body) as Map<String, dynamic>;
            return MemberDownloadResult.fromJson(decoded);
          } else {
            throw Exception(
              'Failed to fetch the member download. Status code: ${response.statusCode}',
            );
          }
        })
        .catchError((_) {
          throw Exception('Failed to fetch url');
        });
  }

  /// Returns a download link for a journal for a given md5.
  Future<String?> getJournalDownloadLinkByMd5(String md5) async {
    try {
      final info = await getInfo(md5);
      final doi = info['codes']?['DOI']?.firstOrNull?.trim();

      if (doi == null) {
        return null;
      }

      return _SciHubApi().getSciHubFileLink(doi);
    } catch (e) {
      return null;
    }
  }

  /// Returns a download link for a journal for a given doi.
  Future<String?> getJournalDownloadLinkByDOI(String doi) async {
    try {
      if (doi.isEmpty) {
        return null;
      }

      return _SciHubApi().getSciHubFileLink(doi);
    } catch (e) {
      return null;
    }
  }
}

class _SciHubApi extends BaseBookApi {
  static const scidbBaseUrl = 'https://sci-hub.se';

  /// This is used to fetch the PDF link for a given DOI from Sci-Hub.
  Future<String?> getSciHubFileLink(String doi) async {
    final scihubLink = '$scidbBaseUrl/$doi';
    return cookSoup(scihubLink)
        .then((soup) {
          final embedSrc = soup.find('embed', id: 'pdf')?.attributes['src'];

          if (embedSrc == null) {
            return null;
          }

          final content = embedSrc
              .replaceAll('#navpanes=0&view=FitH', '')
              .replaceAll('//', '/');

          if (content.startsWith('/downloads') ||
              content.startsWith('/tree') ||
              content.startsWith('/uptodate')) {
            return '$scidbBaseUrl$content';
          }

          return 'https:/$content';
        })
        .catchError((onError) {
          return null;
        });
  }

  @override
  int? getTotalResultCount(BeautifulSoup soup) {
    throw UnimplementedError();
  }
}
