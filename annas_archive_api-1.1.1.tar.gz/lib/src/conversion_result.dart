/// Class to return parsed list<T> with error count
class ConversionResult<T> {
  ConversionResult(this.results, this.errorCount);

  final List<T> results;
  final int errorCount;
}
