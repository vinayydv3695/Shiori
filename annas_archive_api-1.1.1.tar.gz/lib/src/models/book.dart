import 'package:annas_archive_api/src/enums.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'book.freezed.dart';
part 'book.g.dart';

@freezed
abstract class Book with _$Book {
  const factory Book({
    required String title,
    required String author,
    required String md5,
    required String imgUrl,
    required String size,
    required String genre,
    required Format format,
    String? year,
    String? imgFallbackColor,
    @Default([]) List<String> sources,
  }) = _Book;

  factory Book.fromJson(Map<String, Object?> json) => _$BookFromJson(json);
}
