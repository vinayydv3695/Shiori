// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'book.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$Book {

 String get title; String get author; String get md5; String get imgUrl; String get size; String get genre; Format get format; String? get year; String? get imgFallbackColor; List<String> get sources;
/// Create a copy of Book
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$BookCopyWith<Book> get copyWith => _$BookCopyWithImpl<Book>(this as Book, _$identity);

  /// Serializes this Book to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is Book&&(identical(other.title, title) || other.title == title)&&(identical(other.author, author) || other.author == author)&&(identical(other.md5, md5) || other.md5 == md5)&&(identical(other.imgUrl, imgUrl) || other.imgUrl == imgUrl)&&(identical(other.size, size) || other.size == size)&&(identical(other.genre, genre) || other.genre == genre)&&(identical(other.format, format) || other.format == format)&&(identical(other.year, year) || other.year == year)&&(identical(other.imgFallbackColor, imgFallbackColor) || other.imgFallbackColor == imgFallbackColor)&&const DeepCollectionEquality().equals(other.sources, sources));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,title,author,md5,imgUrl,size,genre,format,year,imgFallbackColor,const DeepCollectionEquality().hash(sources));

@override
String toString() {
  return 'Book(title: $title, author: $author, md5: $md5, imgUrl: $imgUrl, size: $size, genre: $genre, format: $format, year: $year, imgFallbackColor: $imgFallbackColor, sources: $sources)';
}


}

/// @nodoc
abstract mixin class $BookCopyWith<$Res>  {
  factory $BookCopyWith(Book value, $Res Function(Book) _then) = _$BookCopyWithImpl;
@useResult
$Res call({
 String title, String author, String md5, String imgUrl, String size, String genre, Format format, String? year, String? imgFallbackColor, List<String> sources
});




}
/// @nodoc
class _$BookCopyWithImpl<$Res>
    implements $BookCopyWith<$Res> {
  _$BookCopyWithImpl(this._self, this._then);

  final Book _self;
  final $Res Function(Book) _then;

/// Create a copy of Book
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? title = null,Object? author = null,Object? md5 = null,Object? imgUrl = null,Object? size = null,Object? genre = null,Object? format = null,Object? year = freezed,Object? imgFallbackColor = freezed,Object? sources = null,}) {
  return _then(_self.copyWith(
title: null == title ? _self.title : title // ignore: cast_nullable_to_non_nullable
as String,author: null == author ? _self.author : author // ignore: cast_nullable_to_non_nullable
as String,md5: null == md5 ? _self.md5 : md5 // ignore: cast_nullable_to_non_nullable
as String,imgUrl: null == imgUrl ? _self.imgUrl : imgUrl // ignore: cast_nullable_to_non_nullable
as String,size: null == size ? _self.size : size // ignore: cast_nullable_to_non_nullable
as String,genre: null == genre ? _self.genre : genre // ignore: cast_nullable_to_non_nullable
as String,format: null == format ? _self.format : format // ignore: cast_nullable_to_non_nullable
as Format,year: freezed == year ? _self.year : year // ignore: cast_nullable_to_non_nullable
as String?,imgFallbackColor: freezed == imgFallbackColor ? _self.imgFallbackColor : imgFallbackColor // ignore: cast_nullable_to_non_nullable
as String?,sources: null == sources ? _self.sources : sources // ignore: cast_nullable_to_non_nullable
as List<String>,
  ));
}

}


/// Adds pattern-matching-related methods to [Book].
extension BookPatterns on Book {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _Book value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _Book() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _Book value)  $default,){
final _that = this;
switch (_that) {
case _Book():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _Book value)?  $default,){
final _that = this;
switch (_that) {
case _Book() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String title,  String author,  String md5,  String imgUrl,  String size,  String genre,  Format format,  String? year,  String? imgFallbackColor,  List<String> sources)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _Book() when $default != null:
return $default(_that.title,_that.author,_that.md5,_that.imgUrl,_that.size,_that.genre,_that.format,_that.year,_that.imgFallbackColor,_that.sources);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String title,  String author,  String md5,  String imgUrl,  String size,  String genre,  Format format,  String? year,  String? imgFallbackColor,  List<String> sources)  $default,) {final _that = this;
switch (_that) {
case _Book():
return $default(_that.title,_that.author,_that.md5,_that.imgUrl,_that.size,_that.genre,_that.format,_that.year,_that.imgFallbackColor,_that.sources);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String title,  String author,  String md5,  String imgUrl,  String size,  String genre,  Format format,  String? year,  String? imgFallbackColor,  List<String> sources)?  $default,) {final _that = this;
switch (_that) {
case _Book() when $default != null:
return $default(_that.title,_that.author,_that.md5,_that.imgUrl,_that.size,_that.genre,_that.format,_that.year,_that.imgFallbackColor,_that.sources);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _Book implements Book {
  const _Book({required this.title, required this.author, required this.md5, required this.imgUrl, required this.size, required this.genre, required this.format, this.year, this.imgFallbackColor, final  List<String> sources = const []}): _sources = sources;
  factory _Book.fromJson(Map<String, dynamic> json) => _$BookFromJson(json);

@override final  String title;
@override final  String author;
@override final  String md5;
@override final  String imgUrl;
@override final  String size;
@override final  String genre;
@override final  Format format;
@override final  String? year;
@override final  String? imgFallbackColor;
 final  List<String> _sources;
@override@JsonKey() List<String> get sources {
  if (_sources is EqualUnmodifiableListView) return _sources;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_sources);
}


/// Create a copy of Book
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$BookCopyWith<_Book> get copyWith => __$BookCopyWithImpl<_Book>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$BookToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _Book&&(identical(other.title, title) || other.title == title)&&(identical(other.author, author) || other.author == author)&&(identical(other.md5, md5) || other.md5 == md5)&&(identical(other.imgUrl, imgUrl) || other.imgUrl == imgUrl)&&(identical(other.size, size) || other.size == size)&&(identical(other.genre, genre) || other.genre == genre)&&(identical(other.format, format) || other.format == format)&&(identical(other.year, year) || other.year == year)&&(identical(other.imgFallbackColor, imgFallbackColor) || other.imgFallbackColor == imgFallbackColor)&&const DeepCollectionEquality().equals(other._sources, _sources));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,title,author,md5,imgUrl,size,genre,format,year,imgFallbackColor,const DeepCollectionEquality().hash(_sources));

@override
String toString() {
  return 'Book(title: $title, author: $author, md5: $md5, imgUrl: $imgUrl, size: $size, genre: $genre, format: $format, year: $year, imgFallbackColor: $imgFallbackColor, sources: $sources)';
}


}

/// @nodoc
abstract mixin class _$BookCopyWith<$Res> implements $BookCopyWith<$Res> {
  factory _$BookCopyWith(_Book value, $Res Function(_Book) _then) = __$BookCopyWithImpl;
@override @useResult
$Res call({
 String title, String author, String md5, String imgUrl, String size, String genre, Format format, String? year, String? imgFallbackColor, List<String> sources
});




}
/// @nodoc
class __$BookCopyWithImpl<$Res>
    implements _$BookCopyWith<$Res> {
  __$BookCopyWithImpl(this._self, this._then);

  final _Book _self;
  final $Res Function(_Book) _then;

/// Create a copy of Book
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? title = null,Object? author = null,Object? md5 = null,Object? imgUrl = null,Object? size = null,Object? genre = null,Object? format = null,Object? year = freezed,Object? imgFallbackColor = freezed,Object? sources = null,}) {
  return _then(_Book(
title: null == title ? _self.title : title // ignore: cast_nullable_to_non_nullable
as String,author: null == author ? _self.author : author // ignore: cast_nullable_to_non_nullable
as String,md5: null == md5 ? _self.md5 : md5 // ignore: cast_nullable_to_non_nullable
as String,imgUrl: null == imgUrl ? _self.imgUrl : imgUrl // ignore: cast_nullable_to_non_nullable
as String,size: null == size ? _self.size : size // ignore: cast_nullable_to_non_nullable
as String,genre: null == genre ? _self.genre : genre // ignore: cast_nullable_to_non_nullable
as String,format: null == format ? _self.format : format // ignore: cast_nullable_to_non_nullable
as Format,year: freezed == year ? _self.year : year // ignore: cast_nullable_to_non_nullable
as String?,imgFallbackColor: freezed == imgFallbackColor ? _self.imgFallbackColor : imgFallbackColor // ignore: cast_nullable_to_non_nullable
as String?,sources: null == sources ? _self._sources : sources // ignore: cast_nullable_to_non_nullable
as List<String>,
  ));
}


}

// dart format on
