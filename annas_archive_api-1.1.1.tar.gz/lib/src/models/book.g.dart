// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'book.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_Book _$BookFromJson(Map<String, dynamic> json) => _Book(
  title: json['title'] as String,
  author: json['author'] as String,
  md5: json['md5'] as String,
  imgUrl: json['imgUrl'] as String,
  size: json['size'] as String,
  genre: json['genre'] as String,
  format: $enumDecode(_$FormatEnumMap, json['format']),
  year: json['year'] as String?,
  imgFallbackColor: json['imgFallbackColor'] as String?,
  sources:
      (json['sources'] as List<dynamic>?)?.map((e) => e as String).toList() ??
      const [],
);

Map<String, dynamic> _$BookToJson(_Book instance) => <String, dynamic>{
  'title': instance.title,
  'author': instance.author,
  'md5': instance.md5,
  'imgUrl': instance.imgUrl,
  'size': instance.size,
  'genre': instance.genre,
  'format': _$FormatEnumMap[instance.format]!,
  'year': instance.year,
  'imgFallbackColor': instance.imgFallbackColor,
  'sources': instance.sources,
};

const _$FormatEnumMap = {
  Format.unknown: 'unknown',
  Format.mobi: 'mobi',
  Format.azw3: 'azw3',
  Format.pdf: 'pdf',
  Format.epub: 'epub',
};
