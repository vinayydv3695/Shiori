import 'package:annas_archive_api/src/models/member_download_result.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'member_download_response.freezed.dart';
part 'member_download_response.g.dart';

@freezed
abstract class MemberDownloadResponse with _$MemberDownloadResponse {
  const factory MemberDownloadResponse({
    required AccountInfo accountInfo,
    required String fast,
    @Default([]) List<String> basic,
  }) = _MemberDownloadResponse;

  factory MemberDownloadResponse.fromJson(Map<String, Object?> json) =>
      _$MemberDownloadResponseFromJson(json);
}
