// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'member_download_response.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$MemberDownloadResponse {

 AccountInfo get accountInfo; String get fast; List<String> get basic;
/// Create a copy of MemberDownloadResponse
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$MemberDownloadResponseCopyWith<MemberDownloadResponse> get copyWith => _$MemberDownloadResponseCopyWithImpl<MemberDownloadResponse>(this as MemberDownloadResponse, _$identity);

  /// Serializes this MemberDownloadResponse to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is MemberDownloadResponse&&(identical(other.accountInfo, accountInfo) || other.accountInfo == accountInfo)&&(identical(other.fast, fast) || other.fast == fast)&&const DeepCollectionEquality().equals(other.basic, basic));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,accountInfo,fast,const DeepCollectionEquality().hash(basic));

@override
String toString() {
  return 'MemberDownloadResponse(accountInfo: $accountInfo, fast: $fast, basic: $basic)';
}


}

/// @nodoc
abstract mixin class $MemberDownloadResponseCopyWith<$Res>  {
  factory $MemberDownloadResponseCopyWith(MemberDownloadResponse value, $Res Function(MemberDownloadResponse) _then) = _$MemberDownloadResponseCopyWithImpl;
@useResult
$Res call({
 AccountInfo accountInfo, String fast, List<String> basic
});


$AccountInfoCopyWith<$Res> get accountInfo;

}
/// @nodoc
class _$MemberDownloadResponseCopyWithImpl<$Res>
    implements $MemberDownloadResponseCopyWith<$Res> {
  _$MemberDownloadResponseCopyWithImpl(this._self, this._then);

  final MemberDownloadResponse _self;
  final $Res Function(MemberDownloadResponse) _then;

/// Create a copy of MemberDownloadResponse
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? accountInfo = null,Object? fast = null,Object? basic = null,}) {
  return _then(_self.copyWith(
accountInfo: null == accountInfo ? _self.accountInfo : accountInfo // ignore: cast_nullable_to_non_nullable
as AccountInfo,fast: null == fast ? _self.fast : fast // ignore: cast_nullable_to_non_nullable
as String,basic: null == basic ? _self.basic : basic // ignore: cast_nullable_to_non_nullable
as List<String>,
  ));
}
/// Create a copy of MemberDownloadResponse
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$AccountInfoCopyWith<$Res> get accountInfo {
  
  return $AccountInfoCopyWith<$Res>(_self.accountInfo, (value) {
    return _then(_self.copyWith(accountInfo: value));
  });
}
}


/// Adds pattern-matching-related methods to [MemberDownloadResponse].
extension MemberDownloadResponsePatterns on MemberDownloadResponse {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _MemberDownloadResponse value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _MemberDownloadResponse() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _MemberDownloadResponse value)  $default,){
final _that = this;
switch (_that) {
case _MemberDownloadResponse():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _MemberDownloadResponse value)?  $default,){
final _that = this;
switch (_that) {
case _MemberDownloadResponse() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( AccountInfo accountInfo,  String fast,  List<String> basic)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _MemberDownloadResponse() when $default != null:
return $default(_that.accountInfo,_that.fast,_that.basic);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( AccountInfo accountInfo,  String fast,  List<String> basic)  $default,) {final _that = this;
switch (_that) {
case _MemberDownloadResponse():
return $default(_that.accountInfo,_that.fast,_that.basic);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( AccountInfo accountInfo,  String fast,  List<String> basic)?  $default,) {final _that = this;
switch (_that) {
case _MemberDownloadResponse() when $default != null:
return $default(_that.accountInfo,_that.fast,_that.basic);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _MemberDownloadResponse implements MemberDownloadResponse {
  const _MemberDownloadResponse({required this.accountInfo, required this.fast, final  List<String> basic = const []}): _basic = basic;
  factory _MemberDownloadResponse.fromJson(Map<String, dynamic> json) => _$MemberDownloadResponseFromJson(json);

@override final  AccountInfo accountInfo;
@override final  String fast;
 final  List<String> _basic;
@override@JsonKey() List<String> get basic {
  if (_basic is EqualUnmodifiableListView) return _basic;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_basic);
}


/// Create a copy of MemberDownloadResponse
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$MemberDownloadResponseCopyWith<_MemberDownloadResponse> get copyWith => __$MemberDownloadResponseCopyWithImpl<_MemberDownloadResponse>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$MemberDownloadResponseToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _MemberDownloadResponse&&(identical(other.accountInfo, accountInfo) || other.accountInfo == accountInfo)&&(identical(other.fast, fast) || other.fast == fast)&&const DeepCollectionEquality().equals(other._basic, _basic));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,accountInfo,fast,const DeepCollectionEquality().hash(_basic));

@override
String toString() {
  return 'MemberDownloadResponse(accountInfo: $accountInfo, fast: $fast, basic: $basic)';
}


}

/// @nodoc
abstract mixin class _$MemberDownloadResponseCopyWith<$Res> implements $MemberDownloadResponseCopyWith<$Res> {
  factory _$MemberDownloadResponseCopyWith(_MemberDownloadResponse value, $Res Function(_MemberDownloadResponse) _then) = __$MemberDownloadResponseCopyWithImpl;
@override @useResult
$Res call({
 AccountInfo accountInfo, String fast, List<String> basic
});


@override $AccountInfoCopyWith<$Res> get accountInfo;

}
/// @nodoc
class __$MemberDownloadResponseCopyWithImpl<$Res>
    implements _$MemberDownloadResponseCopyWith<$Res> {
  __$MemberDownloadResponseCopyWithImpl(this._self, this._then);

  final _MemberDownloadResponse _self;
  final $Res Function(_MemberDownloadResponse) _then;

/// Create a copy of MemberDownloadResponse
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? accountInfo = null,Object? fast = null,Object? basic = null,}) {
  return _then(_MemberDownloadResponse(
accountInfo: null == accountInfo ? _self.accountInfo : accountInfo // ignore: cast_nullable_to_non_nullable
as AccountInfo,fast: null == fast ? _self.fast : fast // ignore: cast_nullable_to_non_nullable
as String,basic: null == basic ? _self._basic : basic // ignore: cast_nullable_to_non_nullable
as List<String>,
  ));
}

/// Create a copy of MemberDownloadResponse
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$AccountInfoCopyWith<$Res> get accountInfo {
  
  return $AccountInfoCopyWith<$Res>(_self.accountInfo, (value) {
    return _then(_self.copyWith(accountInfo: value));
  });
}
}

// dart format on
