// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'member_download_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_MemberDownloadResponse _$MemberDownloadResponseFromJson(
  Map<String, dynamic> json,
) => _MemberDownloadResponse(
  accountInfo: AccountInfo.fromJson(
    json['accountInfo'] as Map<String, dynamic>,
  ),
  fast: json['fast'] as String,
  basic:
      (json['basic'] as List<dynamic>?)?.map((e) => e as String).toList() ??
      const [],
);

Map<String, dynamic> _$MemberDownloadResponseToJson(
  _MemberDownloadResponse instance,
) => <String, dynamic>{
  'accountInfo': instance.accountInfo,
  'fast': instance.fast,
  'basic': instance.basic,
};
