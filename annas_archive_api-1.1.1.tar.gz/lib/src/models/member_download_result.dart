// ignore_for_file: invalid_annotation_target

import 'package:freezed_annotation/freezed_annotation.dart';

part 'member_download_result.freezed.dart';
part 'member_download_result.g.dart';

@freezed
abstract class MemberDownloadResult with _$MemberDownloadResult {
  const factory MemberDownloadResult({
    @JsonKey(name: 'download_url') required String downloadUrl,
    @JsonKey(name: 'account_fast_download_info')
    required AccountInfo accountInfo,
  }) = _MemberDownloadResult;

  factory MemberDownloadResult.fromJson(Map<String, Object?> json) =>
      _$MemberDownloadResultFromJson(json);
}

@freezed
abstract class AccountInfo with _$AccountInfo {
  const factory AccountInfo({
    @JsonKey(name: 'downloads_left') required int downloadsLeft,
    @JsonKey(name: 'downloads_per_day') required int downloadsPerDay,
  }) = _AccountInfo;

  factory AccountInfo.fromJson(Map<String, Object?> json) =>
      _$AccountInfoFromJson(json);
}
