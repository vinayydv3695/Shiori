// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'member_download_result.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$MemberDownloadResult {

@JsonKey(name: 'download_url') String get downloadUrl;@JsonKey(name: 'account_fast_download_info') AccountInfo get accountInfo;
/// Create a copy of MemberDownloadResult
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$MemberDownloadResultCopyWith<MemberDownloadResult> get copyWith => _$MemberDownloadResultCopyWithImpl<MemberDownloadResult>(this as MemberDownloadResult, _$identity);

  /// Serializes this MemberDownloadResult to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is MemberDownloadResult&&(identical(other.downloadUrl, downloadUrl) || other.downloadUrl == downloadUrl)&&(identical(other.accountInfo, accountInfo) || other.accountInfo == accountInfo));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,downloadUrl,accountInfo);

@override
String toString() {
  return 'MemberDownloadResult(downloadUrl: $downloadUrl, accountInfo: $accountInfo)';
}


}

/// @nodoc
abstract mixin class $MemberDownloadResultCopyWith<$Res>  {
  factory $MemberDownloadResultCopyWith(MemberDownloadResult value, $Res Function(MemberDownloadResult) _then) = _$MemberDownloadResultCopyWithImpl;
@useResult
$Res call({
@JsonKey(name: 'download_url') String downloadUrl,@JsonKey(name: 'account_fast_download_info') AccountInfo accountInfo
});


$AccountInfoCopyWith<$Res> get accountInfo;

}
/// @nodoc
class _$MemberDownloadResultCopyWithImpl<$Res>
    implements $MemberDownloadResultCopyWith<$Res> {
  _$MemberDownloadResultCopyWithImpl(this._self, this._then);

  final MemberDownloadResult _self;
  final $Res Function(MemberDownloadResult) _then;

/// Create a copy of MemberDownloadResult
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? downloadUrl = null,Object? accountInfo = null,}) {
  return _then(_self.copyWith(
downloadUrl: null == downloadUrl ? _self.downloadUrl : downloadUrl // ignore: cast_nullable_to_non_nullable
as String,accountInfo: null == accountInfo ? _self.accountInfo : accountInfo // ignore: cast_nullable_to_non_nullable
as AccountInfo,
  ));
}
/// Create a copy of MemberDownloadResult
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$AccountInfoCopyWith<$Res> get accountInfo {
  
  return $AccountInfoCopyWith<$Res>(_self.accountInfo, (value) {
    return _then(_self.copyWith(accountInfo: value));
  });
}
}


/// Adds pattern-matching-related methods to [MemberDownloadResult].
extension MemberDownloadResultPatterns on MemberDownloadResult {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _MemberDownloadResult value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _MemberDownloadResult() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _MemberDownloadResult value)  $default,){
final _that = this;
switch (_that) {
case _MemberDownloadResult():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _MemberDownloadResult value)?  $default,){
final _that = this;
switch (_that) {
case _MemberDownloadResult() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function(@JsonKey(name: 'download_url')  String downloadUrl, @JsonKey(name: 'account_fast_download_info')  AccountInfo accountInfo)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _MemberDownloadResult() when $default != null:
return $default(_that.downloadUrl,_that.accountInfo);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function(@JsonKey(name: 'download_url')  String downloadUrl, @JsonKey(name: 'account_fast_download_info')  AccountInfo accountInfo)  $default,) {final _that = this;
switch (_that) {
case _MemberDownloadResult():
return $default(_that.downloadUrl,_that.accountInfo);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function(@JsonKey(name: 'download_url')  String downloadUrl, @JsonKey(name: 'account_fast_download_info')  AccountInfo accountInfo)?  $default,) {final _that = this;
switch (_that) {
case _MemberDownloadResult() when $default != null:
return $default(_that.downloadUrl,_that.accountInfo);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _MemberDownloadResult implements MemberDownloadResult {
  const _MemberDownloadResult({@JsonKey(name: 'download_url') required this.downloadUrl, @JsonKey(name: 'account_fast_download_info') required this.accountInfo});
  factory _MemberDownloadResult.fromJson(Map<String, dynamic> json) => _$MemberDownloadResultFromJson(json);

@override@JsonKey(name: 'download_url') final  String downloadUrl;
@override@JsonKey(name: 'account_fast_download_info') final  AccountInfo accountInfo;

/// Create a copy of MemberDownloadResult
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$MemberDownloadResultCopyWith<_MemberDownloadResult> get copyWith => __$MemberDownloadResultCopyWithImpl<_MemberDownloadResult>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$MemberDownloadResultToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _MemberDownloadResult&&(identical(other.downloadUrl, downloadUrl) || other.downloadUrl == downloadUrl)&&(identical(other.accountInfo, accountInfo) || other.accountInfo == accountInfo));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,downloadUrl,accountInfo);

@override
String toString() {
  return 'MemberDownloadResult(downloadUrl: $downloadUrl, accountInfo: $accountInfo)';
}


}

/// @nodoc
abstract mixin class _$MemberDownloadResultCopyWith<$Res> implements $MemberDownloadResultCopyWith<$Res> {
  factory _$MemberDownloadResultCopyWith(_MemberDownloadResult value, $Res Function(_MemberDownloadResult) _then) = __$MemberDownloadResultCopyWithImpl;
@override @useResult
$Res call({
@JsonKey(name: 'download_url') String downloadUrl,@JsonKey(name: 'account_fast_download_info') AccountInfo accountInfo
});


@override $AccountInfoCopyWith<$Res> get accountInfo;

}
/// @nodoc
class __$MemberDownloadResultCopyWithImpl<$Res>
    implements _$MemberDownloadResultCopyWith<$Res> {
  __$MemberDownloadResultCopyWithImpl(this._self, this._then);

  final _MemberDownloadResult _self;
  final $Res Function(_MemberDownloadResult) _then;

/// Create a copy of MemberDownloadResult
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? downloadUrl = null,Object? accountInfo = null,}) {
  return _then(_MemberDownloadResult(
downloadUrl: null == downloadUrl ? _self.downloadUrl : downloadUrl // ignore: cast_nullable_to_non_nullable
as String,accountInfo: null == accountInfo ? _self.accountInfo : accountInfo // ignore: cast_nullable_to_non_nullable
as AccountInfo,
  ));
}

/// Create a copy of MemberDownloadResult
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$AccountInfoCopyWith<$Res> get accountInfo {
  
  return $AccountInfoCopyWith<$Res>(_self.accountInfo, (value) {
    return _then(_self.copyWith(accountInfo: value));
  });
}
}


/// @nodoc
mixin _$AccountInfo {

@JsonKey(name: 'downloads_left') int get downloadsLeft;@JsonKey(name: 'downloads_per_day') int get downloadsPerDay;
/// Create a copy of AccountInfo
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$AccountInfoCopyWith<AccountInfo> get copyWith => _$AccountInfoCopyWithImpl<AccountInfo>(this as AccountInfo, _$identity);

  /// Serializes this AccountInfo to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is AccountInfo&&(identical(other.downloadsLeft, downloadsLeft) || other.downloadsLeft == downloadsLeft)&&(identical(other.downloadsPerDay, downloadsPerDay) || other.downloadsPerDay == downloadsPerDay));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,downloadsLeft,downloadsPerDay);

@override
String toString() {
  return 'AccountInfo(downloadsLeft: $downloadsLeft, downloadsPerDay: $downloadsPerDay)';
}


}

/// @nodoc
abstract mixin class $AccountInfoCopyWith<$Res>  {
  factory $AccountInfoCopyWith(AccountInfo value, $Res Function(AccountInfo) _then) = _$AccountInfoCopyWithImpl;
@useResult
$Res call({
@JsonKey(name: 'downloads_left') int downloadsLeft,@JsonKey(name: 'downloads_per_day') int downloadsPerDay
});




}
/// @nodoc
class _$AccountInfoCopyWithImpl<$Res>
    implements $AccountInfoCopyWith<$Res> {
  _$AccountInfoCopyWithImpl(this._self, this._then);

  final AccountInfo _self;
  final $Res Function(AccountInfo) _then;

/// Create a copy of AccountInfo
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? downloadsLeft = null,Object? downloadsPerDay = null,}) {
  return _then(_self.copyWith(
downloadsLeft: null == downloadsLeft ? _self.downloadsLeft : downloadsLeft // ignore: cast_nullable_to_non_nullable
as int,downloadsPerDay: null == downloadsPerDay ? _self.downloadsPerDay : downloadsPerDay // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [AccountInfo].
extension AccountInfoPatterns on AccountInfo {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _AccountInfo value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _AccountInfo() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _AccountInfo value)  $default,){
final _that = this;
switch (_that) {
case _AccountInfo():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _AccountInfo value)?  $default,){
final _that = this;
switch (_that) {
case _AccountInfo() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function(@JsonKey(name: 'downloads_left')  int downloadsLeft, @JsonKey(name: 'downloads_per_day')  int downloadsPerDay)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _AccountInfo() when $default != null:
return $default(_that.downloadsLeft,_that.downloadsPerDay);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function(@JsonKey(name: 'downloads_left')  int downloadsLeft, @JsonKey(name: 'downloads_per_day')  int downloadsPerDay)  $default,) {final _that = this;
switch (_that) {
case _AccountInfo():
return $default(_that.downloadsLeft,_that.downloadsPerDay);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function(@JsonKey(name: 'downloads_left')  int downloadsLeft, @JsonKey(name: 'downloads_per_day')  int downloadsPerDay)?  $default,) {final _that = this;
switch (_that) {
case _AccountInfo() when $default != null:
return $default(_that.downloadsLeft,_that.downloadsPerDay);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _AccountInfo implements AccountInfo {
  const _AccountInfo({@JsonKey(name: 'downloads_left') required this.downloadsLeft, @JsonKey(name: 'downloads_per_day') required this.downloadsPerDay});
  factory _AccountInfo.fromJson(Map<String, dynamic> json) => _$AccountInfoFromJson(json);

@override@JsonKey(name: 'downloads_left') final  int downloadsLeft;
@override@JsonKey(name: 'downloads_per_day') final  int downloadsPerDay;

/// Create a copy of AccountInfo
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$AccountInfoCopyWith<_AccountInfo> get copyWith => __$AccountInfoCopyWithImpl<_AccountInfo>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$AccountInfoToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _AccountInfo&&(identical(other.downloadsLeft, downloadsLeft) || other.downloadsLeft == downloadsLeft)&&(identical(other.downloadsPerDay, downloadsPerDay) || other.downloadsPerDay == downloadsPerDay));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,downloadsLeft,downloadsPerDay);

@override
String toString() {
  return 'AccountInfo(downloadsLeft: $downloadsLeft, downloadsPerDay: $downloadsPerDay)';
}


}

/// @nodoc
abstract mixin class _$AccountInfoCopyWith<$Res> implements $AccountInfoCopyWith<$Res> {
  factory _$AccountInfoCopyWith(_AccountInfo value, $Res Function(_AccountInfo) _then) = __$AccountInfoCopyWithImpl;
@override @useResult
$Res call({
@JsonKey(name: 'downloads_left') int downloadsLeft,@JsonKey(name: 'downloads_per_day') int downloadsPerDay
});




}
/// @nodoc
class __$AccountInfoCopyWithImpl<$Res>
    implements _$AccountInfoCopyWith<$Res> {
  __$AccountInfoCopyWithImpl(this._self, this._then);

  final _AccountInfo _self;
  final $Res Function(_AccountInfo) _then;

/// Create a copy of AccountInfo
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? downloadsLeft = null,Object? downloadsPerDay = null,}) {
  return _then(_AccountInfo(
downloadsLeft: null == downloadsLeft ? _self.downloadsLeft : downloadsLeft // ignore: cast_nullable_to_non_nullable
as int,downloadsPerDay: null == downloadsPerDay ? _self.downloadsPerDay : downloadsPerDay // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
