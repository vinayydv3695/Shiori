// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'member_download_result.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_MemberDownloadResult _$MemberDownloadResultFromJson(
  Map<String, dynamic> json,
) => _MemberDownloadResult(
  downloadUrl: json['download_url'] as String,
  accountInfo: AccountInfo.fromJson(
    json['account_fast_download_info'] as Map<String, dynamic>,
  ),
);

Map<String, dynamic> _$MemberDownloadResultToJson(
  _MemberDownloadResult instance,
) => <String, dynamic>{
  'download_url': instance.downloadUrl,
  'account_fast_download_info': instance.accountInfo,
};

_AccountInfo _$AccountInfoFromJson(Map<String, dynamic> json) => _AccountInfo(
  downloadsLeft: (json['downloads_left'] as num).toInt(),
  downloadsPerDay: (json['downloads_per_day'] as num).toInt(),
);

Map<String, dynamic> _$AccountInfoToJson(_AccountInfo instance) =>
    <String, dynamic>{
      'downloads_left': instance.downloadsLeft,
      'downloads_per_day': instance.downloadsPerDay,
    };
