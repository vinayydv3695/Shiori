import 'package:annas_archive_api/src/enums.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'search_journal_request.freezed.dart';
part 'search_journal_request.g.dart';

@freezed
abstract class SearchJournalRequest with _$SearchJournalRequest {
  const factory SearchJournalRequest({
    required String query,
    @Default('') String author,
    @Default(Language.english) Language language,
    @Default(SortOption.mostRelevant) SortOption sort,
    @Default(1) int page,
    @Default([]) List<AnnaSource> sources,
  }) = _SearchJournalRequest;

  factory SearchJournalRequest.fromJson(Map<String, Object?> json) =>
      _$SearchJournalRequestFromJson(json);
}
