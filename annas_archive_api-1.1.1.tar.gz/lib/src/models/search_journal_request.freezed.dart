// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'search_journal_request.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$SearchJournalRequest {

 String get query; String get author; Language get language; SortOption get sort; int get page; List<AnnaSource> get sources;
/// Create a copy of SearchJournalRequest
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$SearchJournalRequestCopyWith<SearchJournalRequest> get copyWith => _$SearchJournalRequestCopyWithImpl<SearchJournalRequest>(this as SearchJournalRequest, _$identity);

  /// Serializes this SearchJournalRequest to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is SearchJournalRequest&&(identical(other.query, query) || other.query == query)&&(identical(other.author, author) || other.author == author)&&(identical(other.language, language) || other.language == language)&&(identical(other.sort, sort) || other.sort == sort)&&(identical(other.page, page) || other.page == page)&&const DeepCollectionEquality().equals(other.sources, sources));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,query,author,language,sort,page,const DeepCollectionEquality().hash(sources));

@override
String toString() {
  return 'SearchJournalRequest(query: $query, author: $author, language: $language, sort: $sort, page: $page, sources: $sources)';
}


}

/// @nodoc
abstract mixin class $SearchJournalRequestCopyWith<$Res>  {
  factory $SearchJournalRequestCopyWith(SearchJournalRequest value, $Res Function(SearchJournalRequest) _then) = _$SearchJournalRequestCopyWithImpl;
@useResult
$Res call({
 String query, String author, Language language, SortOption sort, int page, List<AnnaSource> sources
});




}
/// @nodoc
class _$SearchJournalRequestCopyWithImpl<$Res>
    implements $SearchJournalRequestCopyWith<$Res> {
  _$SearchJournalRequestCopyWithImpl(this._self, this._then);

  final SearchJournalRequest _self;
  final $Res Function(SearchJournalRequest) _then;

/// Create a copy of SearchJournalRequest
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? query = null,Object? author = null,Object? language = null,Object? sort = null,Object? page = null,Object? sources = null,}) {
  return _then(_self.copyWith(
query: null == query ? _self.query : query // ignore: cast_nullable_to_non_nullable
as String,author: null == author ? _self.author : author // ignore: cast_nullable_to_non_nullable
as String,language: null == language ? _self.language : language // ignore: cast_nullable_to_non_nullable
as Language,sort: null == sort ? _self.sort : sort // ignore: cast_nullable_to_non_nullable
as SortOption,page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as int,sources: null == sources ? _self.sources : sources // ignore: cast_nullable_to_non_nullable
as List<AnnaSource>,
  ));
}

}


/// Adds pattern-matching-related methods to [SearchJournalRequest].
extension SearchJournalRequestPatterns on SearchJournalRequest {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _SearchJournalRequest value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _SearchJournalRequest() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _SearchJournalRequest value)  $default,){
final _that = this;
switch (_that) {
case _SearchJournalRequest():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _SearchJournalRequest value)?  $default,){
final _that = this;
switch (_that) {
case _SearchJournalRequest() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String query,  String author,  Language language,  SortOption sort,  int page,  List<AnnaSource> sources)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _SearchJournalRequest() when $default != null:
return $default(_that.query,_that.author,_that.language,_that.sort,_that.page,_that.sources);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String query,  String author,  Language language,  SortOption sort,  int page,  List<AnnaSource> sources)  $default,) {final _that = this;
switch (_that) {
case _SearchJournalRequest():
return $default(_that.query,_that.author,_that.language,_that.sort,_that.page,_that.sources);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String query,  String author,  Language language,  SortOption sort,  int page,  List<AnnaSource> sources)?  $default,) {final _that = this;
switch (_that) {
case _SearchJournalRequest() when $default != null:
return $default(_that.query,_that.author,_that.language,_that.sort,_that.page,_that.sources);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _SearchJournalRequest implements SearchJournalRequest {
  const _SearchJournalRequest({required this.query, this.author = '', this.language = Language.english, this.sort = SortOption.mostRelevant, this.page = 1, final  List<AnnaSource> sources = const []}): _sources = sources;
  factory _SearchJournalRequest.fromJson(Map<String, dynamic> json) => _$SearchJournalRequestFromJson(json);

@override final  String query;
@override@JsonKey() final  String author;
@override@JsonKey() final  Language language;
@override@JsonKey() final  SortOption sort;
@override@JsonKey() final  int page;
 final  List<AnnaSource> _sources;
@override@JsonKey() List<AnnaSource> get sources {
  if (_sources is EqualUnmodifiableListView) return _sources;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_sources);
}


/// Create a copy of SearchJournalRequest
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$SearchJournalRequestCopyWith<_SearchJournalRequest> get copyWith => __$SearchJournalRequestCopyWithImpl<_SearchJournalRequest>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$SearchJournalRequestToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _SearchJournalRequest&&(identical(other.query, query) || other.query == query)&&(identical(other.author, author) || other.author == author)&&(identical(other.language, language) || other.language == language)&&(identical(other.sort, sort) || other.sort == sort)&&(identical(other.page, page) || other.page == page)&&const DeepCollectionEquality().equals(other._sources, _sources));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,query,author,language,sort,page,const DeepCollectionEquality().hash(_sources));

@override
String toString() {
  return 'SearchJournalRequest(query: $query, author: $author, language: $language, sort: $sort, page: $page, sources: $sources)';
}


}

/// @nodoc
abstract mixin class _$SearchJournalRequestCopyWith<$Res> implements $SearchJournalRequestCopyWith<$Res> {
  factory _$SearchJournalRequestCopyWith(_SearchJournalRequest value, $Res Function(_SearchJournalRequest) _then) = __$SearchJournalRequestCopyWithImpl;
@override @useResult
$Res call({
 String query, String author, Language language, SortOption sort, int page, List<AnnaSource> sources
});




}
/// @nodoc
class __$SearchJournalRequestCopyWithImpl<$Res>
    implements _$SearchJournalRequestCopyWith<$Res> {
  __$SearchJournalRequestCopyWithImpl(this._self, this._then);

  final _SearchJournalRequest _self;
  final $Res Function(_SearchJournalRequest) _then;

/// Create a copy of SearchJournalRequest
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? query = null,Object? author = null,Object? language = null,Object? sort = null,Object? page = null,Object? sources = null,}) {
  return _then(_SearchJournalRequest(
query: null == query ? _self.query : query // ignore: cast_nullable_to_non_nullable
as String,author: null == author ? _self.author : author // ignore: cast_nullable_to_non_nullable
as String,language: null == language ? _self.language : language // ignore: cast_nullable_to_non_nullable
as Language,sort: null == sort ? _self.sort : sort // ignore: cast_nullable_to_non_nullable
as SortOption,page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as int,sources: null == sources ? _self._sources : sources // ignore: cast_nullable_to_non_nullable
as List<AnnaSource>,
  ));
}


}

// dart format on
