// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_journal_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_SearchJournalRequest _$SearchJournalRequestFromJson(
  Map<String, dynamic> json,
) => _SearchJournalRequest(
  query: json['query'] as String,
  author: json['author'] as String? ?? '',
  language:
      $enumDecodeNullable(_$LanguageEnumMap, json['language']) ??
      Language.english,
  sort:
      $enumDecodeNullable(_$SortOptionEnumMap, json['sort']) ??
      SortOption.mostRelevant,
  page: (json['page'] as num?)?.toInt() ?? 1,
  sources:
      (json['sources'] as List<dynamic>?)
          ?.map((e) => $enumDecode(_$AnnaSourceEnumMap, e))
          .toList() ??
      const [],
);

Map<String, dynamic> _$SearchJournalRequestToJson(
  _SearchJournalRequest instance,
) => <String, dynamic>{
  'query': instance.query,
  'author': instance.author,
  'language': _$LanguageEnumMap[instance.language]!,
  'sort': _$SortOptionEnumMap[instance.sort]!,
  'page': instance.page,
  'sources': instance.sources.map((e) => _$AnnaSourceEnumMap[e]!).toList(),
};

const _$LanguageEnumMap = {
  Language.english: 'english',
  Language.german: 'german',
  Language.chinese: 'chinese',
  Language.spanish: 'spanish',
  Language.korean: 'korean',
  Language.french: 'french',
  Language.russian: 'russian',
  Language.italian: 'italian',
  Language.arabic: 'arabic',
  Language.portuguese: 'portuguese',
  Language.japanese: 'japanese',
  Language.latin: 'latin',
  Language.indonesian: 'indonesian',
  Language.polish: 'polish',
  Language.dutch: 'dutch',
  Language.hebrew: 'hebrew',
  Language.hungarian: 'hungarian',
  Language.bangla: 'bangla',
  Language.hindi: 'hindi',
  Language.afrikaans: 'afrikaans',
  Language.thai: 'thai',
  Language.tamil: 'tamil',
  Language.czech: 'czech',
  Language.turkish: 'turkish',
  Language.romanian: 'romanian',
  Language.greek: 'greek',
  Language.lithuanian: 'lithuanian',
  Language.swedish: 'swedish',
  Language.persian: 'persian',
  Language.vietnamese: 'vietnamese',
  Language.fininish: 'fininish',
  Language.gujarati: 'gujarati',
  Language.kinyarwanda: 'kinyarwanda',
  Language.azerbaijani: 'azerbaijani',
  Language.bulgarian: 'bulgarian',
  Language.ukrainian: 'ukrainian',
  Language.catalan: 'catalan',
  Language.irish: 'irish',
  Language.latvian: 'latvian',
  Language.kannada: 'kannada',
  Language.serbian: 'serbian',
  Language.tiebetan: 'tiebetan',
  Language.danish: 'danish',
  Language.croatian: 'croatian',
  Language.slovak: 'slovak',
  Language.javanese: 'javanese',
  Language.urdu: 'urdu',
  Language.norwegian: 'norwegian',
  Language.belarusian: 'belarusian',
  Language.kazakh: 'kazakh',
  Language.mongolian: 'mongolian',
  Language.georgian: 'georgian',
  Language.slovenian: 'slovenian',
  Language.esperanto: 'esperanto',
  Language.galician: 'galician',
  Language.marathi: 'marathi',
  Language.filipino: 'filipino',
  Language.malayalam: 'malayalam',
  Language.kyrgyz: 'kyrgyz',
  Language.quechua: 'quechua',
  Language.swahili: 'swahili',
  Language.bashkir: 'bashkir',
  Language.punjabi: 'punjabi',
  Language.malay: 'malay',
  Language.teleugu: 'teleugu',
  Language.albanian: 'albanian',
  Language.uyghur: 'uyghur',
  Language.armenian: 'armenian',
  Language.shan: 'shan',
};

const _$SortOptionEnumMap = {
  SortOption.newest: 'newest',
  SortOption.oldest: 'oldest',
  SortOption.largest: 'largest',
  SortOption.smallest: 'smallest',
  SortOption.mostRelevant: 'mostRelevant',
};

const _$AnnaSourceEnumMap = {
  AnnaSource.invalid: 'invalid',
  AnnaSource.libgenLi: 'libgenLi',
  AnnaSource.libgenRs: 'libgenRs',
  AnnaSource.zLibrary: 'zLibrary',
  AnnaSource.internetArchive: 'internetArchive',
  AnnaSource.uploads: 'uploads',
  AnnaSource.nexusStc: 'nexusStc',
  AnnaSource.duxiu: 'duxiu',
  AnnaSource.zLibraryChinese: 'zLibraryChinese',
  AnnaSource.magzDb: 'magzDb',
  AnnaSource.sciHub: 'sciHub',
};
