import 'package:annas_archive_api/src/enums.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'search_request.freezed.dart';
part 'search_request.g.dart';

@freezed
abstract class SearchRequest with _$SearchRequest {
  const factory SearchRequest({
    required String query,
    @Default('') String author,
    @Default([]) List<Format> formats,
    @Default(Language.english) Language language,
    @Default([]) List<Category> categories,
    @Default(SortOption.mostRelevant) SortOption sort,
    @Default(1) int page,
    @Default([]) List<AnnaSource> sources,
  }) = _SearchRequest;

  factory SearchRequest.fromJson(Map<String, Object?> json) =>
      _$SearchRequestFromJson(json);
}
