// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'search_request.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$SearchRequest {

 String get query; String get author; List<Format> get formats; Language get language; List<Category> get categories; SortOption get sort; int get page; List<AnnaSource> get sources;
/// Create a copy of SearchRequest
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$SearchRequestCopyWith<SearchRequest> get copyWith => _$SearchRequestCopyWithImpl<SearchRequest>(this as SearchRequest, _$identity);

  /// Serializes this SearchRequest to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is SearchRequest&&(identical(other.query, query) || other.query == query)&&(identical(other.author, author) || other.author == author)&&const DeepCollectionEquality().equals(other.formats, formats)&&(identical(other.language, language) || other.language == language)&&const DeepCollectionEquality().equals(other.categories, categories)&&(identical(other.sort, sort) || other.sort == sort)&&(identical(other.page, page) || other.page == page)&&const DeepCollectionEquality().equals(other.sources, sources));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,query,author,const DeepCollectionEquality().hash(formats),language,const DeepCollectionEquality().hash(categories),sort,page,const DeepCollectionEquality().hash(sources));

@override
String toString() {
  return 'SearchRequest(query: $query, author: $author, formats: $formats, language: $language, categories: $categories, sort: $sort, page: $page, sources: $sources)';
}


}

/// @nodoc
abstract mixin class $SearchRequestCopyWith<$Res>  {
  factory $SearchRequestCopyWith(SearchRequest value, $Res Function(SearchRequest) _then) = _$SearchRequestCopyWithImpl;
@useResult
$Res call({
 String query, String author, List<Format> formats, Language language, List<Category> categories, SortOption sort, int page, List<AnnaSource> sources
});




}
/// @nodoc
class _$SearchRequestCopyWithImpl<$Res>
    implements $SearchRequestCopyWith<$Res> {
  _$SearchRequestCopyWithImpl(this._self, this._then);

  final SearchRequest _self;
  final $Res Function(SearchRequest) _then;

/// Create a copy of SearchRequest
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? query = null,Object? author = null,Object? formats = null,Object? language = null,Object? categories = null,Object? sort = null,Object? page = null,Object? sources = null,}) {
  return _then(_self.copyWith(
query: null == query ? _self.query : query // ignore: cast_nullable_to_non_nullable
as String,author: null == author ? _self.author : author // ignore: cast_nullable_to_non_nullable
as String,formats: null == formats ? _self.formats : formats // ignore: cast_nullable_to_non_nullable
as List<Format>,language: null == language ? _self.language : language // ignore: cast_nullable_to_non_nullable
as Language,categories: null == categories ? _self.categories : categories // ignore: cast_nullable_to_non_nullable
as List<Category>,sort: null == sort ? _self.sort : sort // ignore: cast_nullable_to_non_nullable
as SortOption,page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as int,sources: null == sources ? _self.sources : sources // ignore: cast_nullable_to_non_nullable
as List<AnnaSource>,
  ));
}

}


/// Adds pattern-matching-related methods to [SearchRequest].
extension SearchRequestPatterns on SearchRequest {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _SearchRequest value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _SearchRequest() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _SearchRequest value)  $default,){
final _that = this;
switch (_that) {
case _SearchRequest():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _SearchRequest value)?  $default,){
final _that = this;
switch (_that) {
case _SearchRequest() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String query,  String author,  List<Format> formats,  Language language,  List<Category> categories,  SortOption sort,  int page,  List<AnnaSource> sources)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _SearchRequest() when $default != null:
return $default(_that.query,_that.author,_that.formats,_that.language,_that.categories,_that.sort,_that.page,_that.sources);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String query,  String author,  List<Format> formats,  Language language,  List<Category> categories,  SortOption sort,  int page,  List<AnnaSource> sources)  $default,) {final _that = this;
switch (_that) {
case _SearchRequest():
return $default(_that.query,_that.author,_that.formats,_that.language,_that.categories,_that.sort,_that.page,_that.sources);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String query,  String author,  List<Format> formats,  Language language,  List<Category> categories,  SortOption sort,  int page,  List<AnnaSource> sources)?  $default,) {final _that = this;
switch (_that) {
case _SearchRequest() when $default != null:
return $default(_that.query,_that.author,_that.formats,_that.language,_that.categories,_that.sort,_that.page,_that.sources);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _SearchRequest implements SearchRequest {
  const _SearchRequest({required this.query, this.author = '', final  List<Format> formats = const [], this.language = Language.english, final  List<Category> categories = const [], this.sort = SortOption.mostRelevant, this.page = 1, final  List<AnnaSource> sources = const []}): _formats = formats,_categories = categories,_sources = sources;
  factory _SearchRequest.fromJson(Map<String, dynamic> json) => _$SearchRequestFromJson(json);

@override final  String query;
@override@JsonKey() final  String author;
 final  List<Format> _formats;
@override@JsonKey() List<Format> get formats {
  if (_formats is EqualUnmodifiableListView) return _formats;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_formats);
}

@override@JsonKey() final  Language language;
 final  List<Category> _categories;
@override@JsonKey() List<Category> get categories {
  if (_categories is EqualUnmodifiableListView) return _categories;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_categories);
}

@override@JsonKey() final  SortOption sort;
@override@JsonKey() final  int page;
 final  List<AnnaSource> _sources;
@override@JsonKey() List<AnnaSource> get sources {
  if (_sources is EqualUnmodifiableListView) return _sources;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_sources);
}


/// Create a copy of SearchRequest
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$SearchRequestCopyWith<_SearchRequest> get copyWith => __$SearchRequestCopyWithImpl<_SearchRequest>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$SearchRequestToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _SearchRequest&&(identical(other.query, query) || other.query == query)&&(identical(other.author, author) || other.author == author)&&const DeepCollectionEquality().equals(other._formats, _formats)&&(identical(other.language, language) || other.language == language)&&const DeepCollectionEquality().equals(other._categories, _categories)&&(identical(other.sort, sort) || other.sort == sort)&&(identical(other.page, page) || other.page == page)&&const DeepCollectionEquality().equals(other._sources, _sources));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,query,author,const DeepCollectionEquality().hash(_formats),language,const DeepCollectionEquality().hash(_categories),sort,page,const DeepCollectionEquality().hash(_sources));

@override
String toString() {
  return 'SearchRequest(query: $query, author: $author, formats: $formats, language: $language, categories: $categories, sort: $sort, page: $page, sources: $sources)';
}


}

/// @nodoc
abstract mixin class _$SearchRequestCopyWith<$Res> implements $SearchRequestCopyWith<$Res> {
  factory _$SearchRequestCopyWith(_SearchRequest value, $Res Function(_SearchRequest) _then) = __$SearchRequestCopyWithImpl;
@override @useResult
$Res call({
 String query, String author, List<Format> formats, Language language, List<Category> categories, SortOption sort, int page, List<AnnaSource> sources
});




}
/// @nodoc
class __$SearchRequestCopyWithImpl<$Res>
    implements _$SearchRequestCopyWith<$Res> {
  __$SearchRequestCopyWithImpl(this._self, this._then);

  final _SearchRequest _self;
  final $Res Function(_SearchRequest) _then;

/// Create a copy of SearchRequest
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? query = null,Object? author = null,Object? formats = null,Object? language = null,Object? categories = null,Object? sort = null,Object? page = null,Object? sources = null,}) {
  return _then(_SearchRequest(
query: null == query ? _self.query : query // ignore: cast_nullable_to_non_nullable
as String,author: null == author ? _self.author : author // ignore: cast_nullable_to_non_nullable
as String,formats: null == formats ? _self._formats : formats // ignore: cast_nullable_to_non_nullable
as List<Format>,language: null == language ? _self.language : language // ignore: cast_nullable_to_non_nullable
as Language,categories: null == categories ? _self._categories : categories // ignore: cast_nullable_to_non_nullable
as List<Category>,sort: null == sort ? _self.sort : sort // ignore: cast_nullable_to_non_nullable
as SortOption,page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as int,sources: null == sources ? _self._sources : sources // ignore: cast_nullable_to_non_nullable
as List<AnnaSource>,
  ));
}


}

// dart format on
