import 'package:annas_archive_api/src/anna_api.dart';
import 'package:annas_archive_api/src/enums.dart';
import 'package:annas_archive_api/src/models/search_journal_request.dart';
import 'package:annas_archive_api/src/models/search_request.dart';
import 'package:test/test.dart';

Future<void> main() async {
  test('returns non-empty results for valid search request', () async {
    final annaApi = AnnaApi();
    const searchRequest = SearchRequest(
      query: 'the court of the dead',
      // query: 'leave me behind',
      // author: '',
      categories: [Category.unknown, Category.nonfiction, Category.fiction],
      sources: [AnnaSource.libgenLi, AnnaSource.libgenRs, AnnaSource.zLibrary],
      formats: [Format.epub, Format.pdf],
      // page: 3,
      // language: Language.english,
      // sort: SortOption.mostRelevant,
    );

    final result = await annaApi.find(searchRequest);

    expect(result.books, isNotEmpty);
  });

  test('returns valid download links for search result', () async {
    final annaApi = AnnaApi();

    final downloadResult = await annaApi.getDownloadLinks(
      'F6B0E4034119C4A100BBCE3122B8C3E6',
    );

    expect(downloadResult, isNotEmpty);
  });

  test('returns valid details metaData for existing book md5', () async {
    final annaApi = AnnaApi();

    final detailsResult = await annaApi.getInfo(
      'F6B0E4034119C4A100BBCE3122B8C3E6',
    );

    expect(detailsResult, isNotEmpty);
  });

  test('returns valid member download links for search result', () async {
    final annaApi = AnnaApi();
    const searchRequest = SearchRequest(
      query: 'The book of enoch',
      author: 'Charles, Robert Henry; Gooder, Paula',
    );

    final searchResult = await annaApi.find(searchRequest);

    expect(searchResult.books, isNotEmpty);

    final book = searchResult.books.first;

    final downloadResult = await annaApi.getMemberDownloadLinks(
      md5: book.md5,
      membershipKey: 'your_membership_key_here',
    );
    expect(downloadResult, isNotNull);
  });

  test('returns non-empty results for valid search journal request', () async {
    final annaApi = AnnaApi();
    const searchRequest = SearchJournalRequest(
      query: 'doi:10.1001',
      // author: '',
      // skip: 0,
      // limit: 10,
      // language: Language.english,
      // sort: SortOption.mostRelevant,
    );

    final result = await annaApi.findJournal(searchRequest);

    expect(result.books, isNotEmpty);
  });

  test('returns valid download link for journals by md5', () async {
    final annaApi = AnnaApi();
    final link = await annaApi.getJournalDownloadLinkByMd5(
      'da58604dfb0dfe75a33227cc1bdebbc3',
    );
    expect(link, isNotNull);
  });

  test('returns valid download link for journals by DOI', () async {
    final annaApi = AnnaApi();
    final link = await annaApi.getJournalDownloadLinkByDOI(
      '10.1007/s00192-021-04878-9',
    );
    expect(link, isNotNull);
  });
}
